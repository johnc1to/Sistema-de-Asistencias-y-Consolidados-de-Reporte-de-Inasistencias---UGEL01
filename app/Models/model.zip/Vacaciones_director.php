<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vacaciones_director extends Model
{
    use HasFactory;
    /**
     * The database connection used by the model.
     *
     * @var string
     */
    /**
    * The database table used by the model.
    *
    * @var string
    */
    protected $table = 'vacaciones_director';

    //Etc...
}
